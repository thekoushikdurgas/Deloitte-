DECLARE
    V_USERID           TEXT;
    V_TRG_UPD_DATE_STR TEXT;
BEGIN
    V_USERID := COALESCE(NEW.UPD_USER, OLD.UPD_USER);
    V_TRG_UPD_DATE_STR := TO_CHAR(COALESCE(NEW.UPD_DATE, OLD.UPD_DATE), 'YYYY-MM-DD');
    IF TG_OP = 'UPDATE' THEN
        IF COALESCE (OLD.PROD_FAM_NAME_STATUS_CD, 'X') <> COALESCE (NEW.PROD_FAM_NAME_STATUS_CD, 'X') OR OLD.PROD_FAM_NAME <> NEW.PROD_FAM_NAME OR COALESCE(OLD.ACT_SUBSTANCE_NAME, 'X') <> COALESCE(NEW.ACT_SUBSTANCE_NAME, 'X') THEN
            CASE
                WHEN NEW.PROD_FAM_NAME_STATUS_CD IN ('T', 'R') THEN
                    UPDATE GMD.THEME_MOLECULES
                    SET
                        MOLECULE_DESC = NEW.PROD_FAM_NAME
                    WHERE
                        PRODUCT_FAMILY_CD = NEW.PRODUCT_FAMILY_CD;
                WHEN NEW.PROD_FAM_NAME_STATUS_CD IN ('G', 'I') THEN
                    UPDATE GMD.THEME_MOLECULES
                    SET
                        MOLECULE_DESC = NEW.ACT_SUBSTANCE_NAME
                    WHERE
                        PRODUCT_FAMILY_CD = NEW.PRODUCT_FAMILY_CD;
                ELSE
                    NULL;
            END CASE;

            CALL GMD.GMD_UTIL_THEMES$UPD_THEME_DESC_JOB_PROC(
                P_PRODUCT_FAMILY_CD => NEW.PRODUCT_FAMILY_CD::TEXT,
                P_REGISTRAR => V_USERID::TEXT,
                P_TRG_TABLE => 'PRODUCT_FAMILIES'::TEXT,
                P_TRG_UPD_DATE => V_TRG_UPD_DATE_STR::TEXT
            );
        END IF;
    END IF;

    RETURN NULL;
END;